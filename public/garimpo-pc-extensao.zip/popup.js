'use strict';

/**
 * Popup da extensão: botão "Garimpar" + configuração (token/URLs).
 * O trabalho pesado (print da página toda + envio pro backend) é do background.js.
 */

const DEFAULTS = {
  apiUrl: 'https://garimpo-pc-api-production.up.railway.app',
  appUrl: 'https://garimpo-pc-frontend.vercel.app',
  token: '',
};

const $ = (id) => document.getElementById(id);
const status = $('status');

function mostrar(msg, classe) {
  status.textContent = msg;
  status.className = classe || '';
}

// carrega config salva nos campos
chrome.storage.sync.get(DEFAULTS, (cfg) => {
  $('token').value = cfg.token;
  $('apiUrl').value = cfg.apiUrl;
  $('appUrl').value = cfg.appUrl;
  if (!cfg.token) {
    $('cfg').open = true;
    mostrar('Primeira vez: cole o token do app em ⚙️ Configuração.', 'erro');
  }
});

$('salvarCfg').addEventListener('click', () => {
  chrome.storage.sync.set(
    {
      token: $('token').value.trim(),
      apiUrl: ($('apiUrl').value.trim() || DEFAULTS.apiUrl).replace(/\/+$/, ''),
      appUrl: ($('appUrl').value.trim() || DEFAULTS.appUrl).replace(/\/+$/, ''),
    },
    () => mostrar('Configuração salva. ✓', 'ok')
  );
});

$('garimpar').addEventListener('click', async () => {
  const cfg = await chrome.storage.sync.get(DEFAULTS);
  if (!cfg.token) {
    $('cfg').open = true;
    mostrar('Cole o token do app antes (⚙️ Configuração).', 'erro');
    return;
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https?:\/\//.test(tab.url || '')) {
    mostrar('Abra a página do anúncio antes de garimpar.', 'erro');
    return;
  }

  $('garimpar').disabled = true;
  mostrar('📸 Capturando a página inteira…');

  chrome.runtime.sendMessage({ acao: 'garimpar', tabId: tab.id }, (resp) => {
    $('garimpar').disabled = false;
    if (chrome.runtime.lastError) {
      mostrar('Erro: ' + chrome.runtime.lastError.message, 'erro');
      return;
    }
    if (!resp || !resp.ok) {
      mostrar('Erro: ' + (resp && resp.erro ? resp.erro : 'falha desconhecida'), 'erro');
      return;
    }
    mostrar(`✅ ${resp.titulo || 'PC'} analisado!\nVeredito: ${resp.veredito} · abrindo o app…`, 'ok');
  });
});

// progresso vindo do background (a análise da IA demora ~10-30s)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.acao === 'progresso') mostrar(msg.texto);
});
