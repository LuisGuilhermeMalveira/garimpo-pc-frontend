'use strict';

/**
 * Popup da extensão: botão "Garimpar" + configuração (token/URLs).
 * O trabalho pesado (print da página toda + envio pro backend) é do background.js.
 */

const DEFAULTS = {
  apiUrl: 'https://garimpo-pc-api-production.up.railway.app',
  appUrl: 'https://garimpo-pc-frontend.vercel.app',
  token: '',
};

const $ = (id) => document.getElementById(id);
const status = $('status');

function mostrar(msg, classe) {
  status.textContent = msg;
  status.className = classe || '';
}

// carrega config salva nos campos
chrome.storage.sync.get(DEFAULTS, (cfg) => {
  $('token').value = cfg.token;
  $('apiUrl').value = cfg.apiUrl;
  $('appUrl').value = cfg.appUrl;
  if (!cfg.token) {
    $('cfg').open = true;
    mostrar('Primeira vez: cole o token do app em ⚙️ Configuração.', 'erro');
  }
});

$('salvarCfg').addEventListener('click', () => {
  chrome.storage.sync.set(
    {
      token: $('token').value.trim(),
      apiUrl: ($('apiUrl').value.trim() || DEFAULTS.apiUrl).replace(/\/+$/, ''),
      appUrl: ($('appUrl').value.trim() || DEFAULTS.appUrl).replace(/\/+$/, ''),
    },
    () => mostrar('Configuração salva. ✓', 'ok')
  );
});

$('garimpar').addEventListener('click', async () => {
  const cfg = await chrome.storage.sync.get(DEFAULTS);
  if (!cfg.token) {
    $('cfg').open = true;
    mostrar('Cole o token do app antes (⚙️ Configuração).', 'erro');
    return;
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https?:\/\//.test(tab.url || '')) {
    mostrar('Abra a página do anúncio antes de garimpar.', 'erro');
    return;
  }

  $('garimpar').disabled = true;
  mostrar('📸 Capturando a página inteira…');

  chrome.runtime.sendMessage({ acao: 'garimpar', tabId: tab.id }, (resp) => {
    $('garimpar').disabled = false;
    if (chrome.runtime.lastError) {
      mostrar('Erro: ' + chrome.runtime.lastError.message, 'erro');
      return;
    }
    if (!resp || !resp.ok) {
      mostrar('Erro: ' + (resp && resp.erro ? resp.erro : 'falha desconhecida'), 'erro');
      return;
    }
    mostrar(`✅ Print carregado no app!\nRevise e toque em Analisar lá.`, 'ok');
  });
});

// 📊 calibração automática: página de BUSCA -> identifica as peças e grava as medianas
$('calibrar').addEventListener('click', async () => {
  const cfg = await chrome.storage.sync.get(DEFAULTS);
  if (!cfg.token) {
    $('cfg').open = true;
    mostrar('Cole o token do app antes (⚙️ Configuração).', 'erro');
    return;
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https?:\/\//.test(tab.url || '')) {
    mostrar('Abra a página de BUSCA (ex.: "gtx 1660" na OLX) antes.', 'erro');
    return;
  }

  $('calibrar').disabled = true;
  $('garimpar').disabled = true;
  mostrar('📸 Capturando a busca inteira…');

  chrome.runtime.sendMessage({ acao: 'calibrar', tabId: tab.id }, (resp) => {
    $('calibrar').disabled = false;
    $('garimpar').disabled = false;
    if (chrome.runtime.lastError) {
      mostrar('Erro: ' + chrome.runtime.lastError.message, 'erro');
      return;
    }
    if (!resp || !resp.ok) {
      mostrar('Erro: ' + (resp && resp.erro ? resp.erro : 'falha desconhecida'), 'erro');
      return;
    }
    const linhas = resp.calibradas.map(
      (c) =>
        `${c.amostras < 8 ? '⚠️' : '✓'} ${c.peca}: R$${c.preco_mediana} (${c.amostras} amostra${
          c.amostras === 1 ? '' : 's'
        }${c.amostras < 8 ? ' — base fraca' : ''})`
    );
    if (resp.ignoradas.length) linhas.push(`✗ ${resp.ignoradas.length} grupo(s) ignorado(s)`);
    if (!resp.calibradas.length) linhas.unshift('Nenhuma peça calibrada — é uma página de busca com peças avulsas?');
    mostrar(linhas.join('\n'), resp.calibradas.length ? 'ok' : 'erro');

    // já gravou no banco — agora oferece baixar o print (opcional, sob clique)
    if (resp.print_b64) oferecerDownload(resp.print_b64, 'calibracao');
  });
});

// mostra o botão "💾 Baixar o print" e arma o download sob clique.
// Só dispara o "Salvar como" quando o Luís clicar — nunca automático.
function oferecerDownload(b64, prefixo) {
  const btn = $('baixar');
  btn.style.display = 'block';
  btn.onclick = () => {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const a = document.createElement('a');
    a.href = `data:image/jpeg;base64,${b64}`;
    a.download = `${prefixo}-${stamp}.jpg`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };
}

// progresso vindo do background (a análise da IA demora ~10-30s)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.acao === 'progresso') {
    mostrar(msg.texto);
    $('baixar').style.display = 'none'; // some enquanto roda de novo
  }
});
