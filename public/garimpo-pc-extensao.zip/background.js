'use strict';

/**
 * Service worker da extensão garimpo-pc.
 *
 * Fluxo do "Garimpar":
 *  1. Print da PÁGINA INTEIRA (chrome.debugger + Page.captureScreenshot com
 *     captureBeyondViewport — pega até o que está fora da tela, sem rolar).
 *  2. Salva uma cópia do print em Downloads/garimpo-pc/ (backup do Luís).
 *  3. Pega também o texto visível da página (ajuda o parser da IA).
 *  4. POST /prospeccoes/analisar (print + texto + link + origem).
 *  5. POST /prospeccoes (grava no histórico).
 *  6. Abre o app na triagem com o PC carregado pra revisão.
 *
 * Roda no SEU navegador, com seu IP e sua sessão — a OLX não diferencia de você.
 */

const DEFAULTS = {
  apiUrl: 'https://garimpo-pc-api-production.up.railway.app',
  appUrl: 'https://garimpo-pc-frontend.vercel.app',
  token: '',
};

function origemDoUrl(url) {
  const h = new URL(url).hostname;
  if (h.includes('olx')) return 'olx';
  if (h.includes('facebook') || h.includes('fb.com')) return 'facebook';
  return 'outro';
}

function progresso(texto) {
  chrome.runtime.sendMessage({ acao: 'progresso', texto }).catch(() => {});
}

// ---- captura de página inteira via protocolo de debug --------------------

function attach(tabId) {
  return new Promise((res, rej) => {
    chrome.debugger.attach({ tabId }, '1.3', () =>
      chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res()
    );
  });
}
function detach(tabId) {
  return new Promise((res) => chrome.debugger.detach({ tabId }, () => {
    void chrome.runtime.lastError; // já desanexado? tanto faz
    res();
  }));
}
function cmd(tabId, metodo, params) {
  return new Promise((res, rej) => {
    chrome.debugger.sendCommand({ tabId }, metodo, params || {}, (out) =>
      chrome.runtime.lastError ? rej(new Error(chrome.runtime.lastError.message)) : res(out)
    );
  });
}

const ALTURA_MAX = 10000; // teto: acima disso é feed de recomendação, não anúncio

// rola a página até o fim (força a OLX/FB a carregar o conteúdo preguiçoso —
// sem isso o print sai cheio de esqueleto cinza) e volta pro topo.
async function prerolarPagina(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    func: async (limite) => {
      const passo = Math.max(400, window.innerHeight - 100);
      const fim = () => Math.min(document.documentElement.scrollHeight, limite);
      for (let y = 0; y < fim(); y += passo) {
        window.scrollTo(0, y);
        await new Promise((r) => setTimeout(r, 120));
      }
      window.scrollTo(0, 0);
      await new Promise((r) => setTimeout(r, 400));
    },
    args: [ALTURA_MAX],
  });
}

async function capturarPaginaInteira(tabId) {
  await prerolarPagina(tabId);
  await attach(tabId);
  try {
    const metrics = await cmd(tabId, 'Page.getLayoutMetrics');
    const cs = metrics.cssContentSize || metrics.contentSize;
    const largura = Math.min(Math.ceil(cs.width), 1920);
    const altura = Math.min(Math.ceil(cs.height), ALTURA_MAX);

    // técnica robusta: "estica" a janela virtual pro tamanho da página inteira
    // (tudo vira viewport de verdade -> nada de repetição de sticky/skeleton)
    await cmd(tabId, 'Emulation.setDeviceMetricsOverride', {
      width: largura,
      height: altura,
      deviceScaleFactor: 1,
      mobile: false,
    });
    await new Promise((r) => setTimeout(r, 600)); // deixa a página re-renderizar

    const shot = await cmd(tabId, 'Page.captureScreenshot', {
      format: 'jpeg',
      quality: 82,
      clip: { x: 0, y: 0, width: largura, height: altura, scale: 1 },
      captureBeyondViewport: false,
    });

    await cmd(tabId, 'Emulation.clearDeviceMetricsOverride');
    return shot.data; // base64 sem prefixo
  } finally {
    await detach(tabId);
  }
}

// ---- texto visível da página ----------------------------------------------

async function textoDaPagina(tabId) {
  const [r] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => ({
      titulo: document.title || '',
      url: location.href,
      texto: (document.body ? document.body.innerText : '').slice(0, 12000),
    }),
  });
  return r.result;
}

// ---- fluxo principal -------------------------------------------------------

async function garimpar(tabId) {
  const cfg = await chrome.storage.sync.get(DEFAULTS);
  if (!cfg.token) throw new Error('Token não configurado (⚙️ no popup).');
  const api = cfg.apiUrl.replace(/\/+$/, '');
  const auth = { Authorization: `Bearer ${cfg.token}` };

  progresso('📸 Capturando a página inteira…');
  const pagina = await textoDaPagina(tabId);
  const b64 = await capturarPaginaInteira(tabId);
  const origem = origemDoUrl(pagina.url);

  // backup do print em Downloads/garimpo-pc/
  const nomeArq = `garimpo-pc/print-${new Date().toISOString().replace(/[:.]/g, '-')}.jpg`;
  try {
    await chrome.downloads.download({
      url: `data:image/jpeg;base64,${b64}`,
      filename: nomeArq,
      conflictAction: 'uniquify',
    });
  } catch (_) {
    /* download é cortesia; não trava o fluxo */
  }

  progresso('🧠 IA lendo o anúncio (10–30s)…');
  const bin = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
  const form = new FormData();
  form.append('imagem', new Blob([bin], { type: 'image/jpeg' }), 'print.jpg');
  form.append('texto', `${pagina.titulo}\n${pagina.texto}`);
  form.append('origem', origem);
  form.append('link', pagina.url);

  const r1 = await fetch(`${api}/prospeccoes/analisar`, {
    method: 'POST',
    headers: auth,
    body: form,
  });
  const analisado = await r1.json();
  if (!r1.ok) throw new Error(analisado.erro || `análise falhou (${r1.status})`);

  progresso('💾 Salvando no histórico…');
  const r2 = await fetch(`${api}/prospeccoes`, {
    method: 'POST',
    headers: { ...auth, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      raw_extracao: analisado.raw_extracao,
      origem,
      link_origem: pagina.url,
      imagem_url: analisado.imagem_url || null,
      titulo: analisado.raw_extracao.titulo || pagina.titulo.slice(0, 120),
    }),
  });
  const salvo = await r2.json();
  if (!r2.ok) throw new Error(salvo.erro || `salvar falhou (${r2.status})`);

  // abre o app com o PC carregado pra revisão
  await chrome.tabs.create({ url: `${cfg.appUrl.replace(/\/+$/, '')}/triagem?edit=${salvo.id}` });

  return {
    ok: true,
    id: salvo.id,
    atualizado: !!salvo.atualizado, // já existia (mesmo link) e foi refrescado
    titulo: analisado.raw_extracao.titulo || pagina.titulo,
    veredito: (analisado.analise && analisado.analise.veredito) || '—',
  };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.acao === 'garimpar') {
    garimpar(msg.tabId)
      .then(sendResponse)
      .catch((e) => sendResponse({ ok: false, erro: e.message }));
    return true; // resposta assíncrona
  }
});
